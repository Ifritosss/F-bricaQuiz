const certaResposta = ['Reduzir acidentes e lesões', 'Proteger contra riscos específicos', 'Identificação e Avaliação de possíveis perigos', 'Garantir a conformidade com regulamentação', 'Regulamentações de segurança e saúde no trabalho', 'Um guia para saídas de emergência e procedimentos', 'Diálogo Diário de Segurança', 'Uma representação gráfica dos riscos presentes no ambiente de trabalho', 'Prevenir lesões relacionadas ao trabalho', 'Documento que registra as atividades do trabalhador e as condições ambientais', 'Diálogo Diário de Segurança e Meio Ambiente', 'Um conjunto de normas e procedimentos para gerenciar riscos ocupacionais']
function principal(button) {
    console.log(button)
    if (certaResposta.includes(button.value)) {
        button.classList.add('certo')
    } else {
        button.classList.add('errado')
    }
}